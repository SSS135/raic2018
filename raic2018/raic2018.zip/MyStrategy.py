
class MyStrategy:
    def act(self, me, rules, game, action):
        with open('/output/test.txt', 'r') as file:
            file.readlines()
        action.target_velocity_z = 1
        action.target_velocity_x = -1